#include <windows.h>
#include <gl/glew.h>
#include <gl/glut.h>
#include <gl/glaux.h>
#include <ctime>
#include <cstdio>
#include "Classes/Headers/FirstPersonCamera.h"
#include <vector>
#include"Bullet.h"
#include"RedCone.h"   // lama bashelhaa betedee errors !! 
#include <sstream>
#include "Classes/Headers/texture.h"
#include "Classes/Headers/md2.h"
#include<iostream>
using namespace std;
 
 
#pragma comment(lib, "glew32.lib")
#pragma comment(lib, "glaux.lib")
#pragma comment(lib, "opengl32.lib")
//#pragma comment(lib, "glu32.lib")
//#pragma comment(lib, "glut32.lib")
//#pragma comment(lib, "SDL.lib")
//#pragma comment(lib, "SDLmain.lib")
/*** Global Variables ***/
 
 
 
 
int largc;
char** largs;
int mode = 0 ;
UINT prevFrameTime = 0;
float spotAngle = 0;
float dtSec = 0;
int Camera_Mode1 = 1 ;   //Sniper Mode.
float SniperAngle=0;
float SniperX=0;
float SniperZ=0;
float speed=10;
float SniperH=0;
int CamPos=60;          
int done1 , done2 , done3 , done4 , done5,done6 , done7 , done8 , done9 , done10 , done11 , done12  , done13 , done14 , done15 , done16 ;
vector<Bullet> bullets;
float PI=0.017453292519943295769236907684883;
FirstPersonCamera camera;
float beastAngle = 0;
float animTimeSec = 0;
//GLuint texture;
GameManager game;
bool SniperMode = false;
 
/*** Methods ***/
void InitGraphics(int argc, char *argv[]);
void InitEnemies();
void RenderEnemiesCones();
void CheckCollisions();
void SetLights();
void DrawCube();
void DrawSquare();
void Draw3DSolarSystem();
float fRotAroundY;
void DrawSquare(int x,int y);
void RenderPlants();
 
GLuint texture1 [6];
GLuint texture;
float width  = 1500;
float height = 1500;
float length = 4000;
 
GLuint LoadTexture( const char * filename, int width, int height) {
    GLuint texture;
    unsigned char * data;
    FILE* file;
 
    file = fopen( filename, "rb" );
    if ( file == NULL ) return 0;
    data = (unsigned char *)malloc( width * height * 3 );
    fread( data, width * height * 3, 1, file );
    fclose( file );
 
    glGenTextures( 1, &texture ); 
    glBindTexture( GL_TEXTURE_2D, texture ); 
    glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE ); 
 
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR );
 
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
 
    gluBuild2DMipmaps( GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data );    
    free(data);
    return texture; 
}  
void DrawSniper()
{
        glPushMatrix();
        glBegin(GL_LINES);
                glColor3f(0, 0, 0);
                glVertex3f(camera.P.x + 70, camera.P.y, camera.P.z - 20);
                glVertex3f(camera.P.x - 70, camera.P.y, camera.P.z - 20);
        glEnd();
        glPopMatrix();
}
 
GLuint LoadTextureRAW( const char * filename, int wrap )
{
  GLuint texture;
  int width, height;
  BYTE * data;
  FILE * file;
 
  // open texture data
  file = fopen( filename, "rb" );
  if ( file == NULL ) return 0;
 
  // allocate buffer
  width = 256;
  height = 256;
  data = (BYTE*)malloc( width * height * 3 );
 
  // read texture data
  fread( data, width * height * 3, 1, file );
  fclose( file );
 
  // allocate a texture name
  glGenTextures( 1, &texture );
 
  // select our current texture
  glBindTexture( GL_TEXTURE_2D, texture );
 
  // select modulate to mix texture with color for shading
//  glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
 
 
  // when texture area is small, bilinear filter the closest MIP map
 // glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
   //                GL_LINEAR_MIPMAP_NEAREST );
  // when texture area is large, bilinear filter the first MIP map
 // glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
 
  // if wrap is true, the texture wraps over at the edges (repeat)
  //       ... false, the texture ends at the edges (clamp)
  //glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,
    //               wrap ? GL_REPEAT : GL_CLAMP );
  //glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,
    //               wrap ? GL_REPEAT : GL_CLAMP );
 
  // build our texture MIP maps
  
  gluBuild2DMipmaps( GL_TEXTURE_2D, 3, width,
    height, GL_RGB, GL_UNSIGNED_BYTE, data );
 
  // free buffer
  free( data );
 
  return texture;
 
}
 
void skybox() 
{
//float x = 30;
//float y = 30;
//float z = 30;
// 
//// Bind the BACK texture of the sky map to the BACK side of the cube
//glBindTexture(GL_TEXTURE_2D, texture1[0]);
//// Center the skybox
//x = x - width  / 2;
//y = y - height / 2;
//z = z - length / 2;
//glBegin(GL_QUADS);      
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y,  z);
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height, z); 
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x, y + height, z);
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x, y,  z);
//glEnd();
//glBindTexture(GL_TEXTURE_2D, texture1[1]);
//glBegin(GL_QUADS);  
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x, y,  z + length);
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x, y + height, z + length);
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z + length); 
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y,  z + length);
//glEnd();
// 
//glBindTexture(GL_TEXTURE_2D, texture1[4]);
//glBegin(GL_QUADS);      
// 
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x, y,  z);
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x, y,  z + length);
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y,  z + length); 
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y,  z);
//glEnd();
//glBindTexture(GL_TEXTURE_2D, texture1[5]);
//glBegin(GL_QUADS);      
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y + height, z);
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y + height, z + length); 
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x, y + height, z + length);
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x, y + height, z);
//glEnd();
//glBindTexture(GL_TEXTURE_2D, texture1[2]);
//glBegin(GL_QUADS);      
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x, y + height, z); 
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x, y + height, z + length); 
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x, y,  z + length);
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x, y,  z);     
// 
//glEnd();
//glBindTexture(GL_TEXTURE_2D, texture1[3]);
//glBegin(GL_QUADS);  
//
//    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y,  z);
//    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y,  z + length);
//    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height, z + length); 
//    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z);
//glEnd();
////glBindTexture( GL_TEXTURE_CUBE_MAP, texture[0] ); //bind the texture
////glRotatef( angle, 1.0f, 1.0f, 1.0f );
////glutSolidSphere(2, 40, 40);
}
 
 
 
//vector<HealthPacket> greenBullets;
//ISoundEngine* engine;
string toString(int n)
{
        string str;
        stringstream ss;
        ss << n;
        ss >> str;
        return str;
}
int getLevel(int mode)
{
        //level 1
        if (mode >= 0 && mode <= 7)
                return 1;
        //level 2
        if (mode >=8 && mode <= 10)
                return 2;
        //level 3
        if (mode >= 11 && mode <= 12)
                return 3;
        if (mode >= 13 )
                return 4;
}
unsigned int LoadTexture(LPCWSTR fileName) { 
        unsigned int texId;
        AUX_RGBImageRec *pBitmap = NULL;
 
        pBitmap = auxDIBImageLoadW(fileName);
        
        if (pBitmap == NULL)
        {
                // No image found, or bad format.
                throw exception("Cannot load the specified image");
        }
        //get an id
        glGenTextures(1, &texId);
         //select/allocate&select the texture object with id
   glBindTexture(GL_TEXTURE_2D, texId);
        //load the bitmap into video memory
        gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pBitmap->sizeX, pBitmap->sizeY, GL_RGB, GL_UNSIGNED_BYTE, pBitmap->data);
                //MinFIlter <-- LInear
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);           // Linear Filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);           // Linear Filtering
 
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);       // Clamping Parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);       // Clamping Parameters
 
        // C++ does not manage the memory. You have to manage it yourself.
        if (pBitmap)                                                                            // If we loaded the bitmap
        {
                if (pBitmap->data)                                                              // If there is texture data
                        free(pBitmap->data);                                            // Free the texture data, we don't need it anymore
                free(pBitmap);                                                                  // Free the bitmap structure
        }
        
        return texId;
}
void SetLights()  // lights
{
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
 
static GLfloat SpecularLight[] = {1.0, 1.0, 1.0};
static GLfloat DiffuseLight[] = {1.0, 1.0, 1.0}; 
static GLfloat AmbientLight[] = {0.2, 0.2, 0.2};
static GLfloat LightPosition[] = {0.0, 50.0, 0.0, 0.0}; 
glLightfv (GL_LIGHT0, GL_SPECULAR, SpecularLight); 
glLightfv (GL_LIGHT0, GL_DIFFUSE, DiffuseLight); 
glLightfv (GL_LIGHT0, GL_AMBIENT, AmbientLight); 
glLightfv (GL_LIGHT0, GL_POSITION, LightPosition);
}
 
void SetMaterial()  // lights
{
        float mat0_diffuse[4] =  { 1, 1, 1, 1 };
 
        float mat0_ambient[4] =  { 1, 1, 1, 1 };
 
        float mat0_specular[4] =  { 0.1, 0.1, .1, .1 };
 
        float mat0_shininess = 10;
        float mat0_emission[4] =  { 0, 0, 0, 1 };
 
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat0_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat0_ambient);
 
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat0_specular);
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat0_shininess);
 
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, mat0_emission);
}
 
void SetTransformations() {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(50, 800.0/800, 0.25, 1000);
 
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity(); //CT <- I
        camera.Tellgl( Camera_Mode1 , game.hero.P );
        
}
 
void OnKeyboard(unsigned char c, int x, int y) {
        
        if(c == 27)      //esc    <orignal>   // not Sniper Mode.
        {
                Camera_Mode1=1 ; 
        }
        else if (c == 13 )  // enter    < inside  //  Sniper Mode.
        {
                Camera_Mode1=0 ; 
                SniperMode = true;
        }
 
        switch(toupper(c))      
        {
                case ' ':  // SHOOT 
                        {
                                // here i'am taking the CAM direction to modify the Bullet velocty
                FirstPersonCamera Tmp;   
                        if ( Camera_Mode1){     
                        Tmp.Reset(SniperX,5 ,SniperZ,
                                SniperX+100*sin(SniperAngle*PI), 5, SniperZ-100*cos(SniperAngle*PI),
                                0,1,0);
                        }
                        else {                  // for the Sniper Mode.  i will give it the hero position 
                                Tmp.Reset(game.hero.P.x,5 ,game.hero.P.z,
                                SniperX+100*sin(SniperAngle*PI), 5, SniperZ-100*cos(SniperAngle*PI),
                                0,1,0);
                        }
                        Vector3 temp = 200 * Tmp.GetLookDirection();     // MSH lee 200 
                        Bullet BB (Tmp.P,Vector3(temp.x , -40  , temp.z));
                        game.heroBullets.push_back(BB);
 
                        }
                break; 
                
                
                //to pause game
        case 'S':
                int ret = MessageBox(NULL, "Game Paused\nTo continue press Yes to exit game press No", "Pause", MB_YESNO);
                if (ret == IDNO)
                        exit(0);
                break;
        
        }
 
}
 
 
void OnSpecial(int key,int x,int y)
{
        float Tz=SniperZ,Tx=SniperX,Px,Py,Pz;
        switch(key)
        {
                case GLUT_KEY_LEFT:
                        SniperAngle-=3.6;
                        break;
                case GLUT_KEY_RIGHT:
                        SniperAngle+=3.6;
                        break;
                case GLUT_KEY_UP:
                        Tz-=speed*cos(SniperAngle*PI);
                    Tx+=speed*sin(SniperAngle*PI);
                        break;
                case GLUT_KEY_DOWN:
                        Tz+=speed*cos(SniperAngle*PI);
                    Tx-=speed*sin(SniperAngle*PI);
                        break;
                /*case GLUT_KEY_END:
                        
                        break;*/
                /*case ' ':
                        terran.SetAnim( ATTACK  );
                        PlaySoundA("rifle.wav",NULL,SND_ASYNC);
                        terran.SetAnim(RUN);
                        if(Ammunition<1)
                                break;*/
                        
                        game.hero.angle= SniperAngle ; 
                        game.hero.angleX= SniperX ; 
                        game.hero.angleZ= SniperZ ; 
 
                        
        };
        if(Tx<1490 && Tx>-1490)
                SniperX=Tx;
 
        if(Tz<1490 && Tz>-1490)
                SniperZ=Tz;
        Px=SniperX-CamPos*sin(SniperAngle*PI);
        Pz=SniperZ+CamPos*cos(SniperAngle*PI);
        Py=15;
        camera.Reset(Px,Py+10,Pz,(SniperX+(1500/Py)*sin(SniperAngle*PI)),0,(SniperZ-(1500/Py)*cos(SniperAngle*PI)),
                0,1,0);
 
        
}
float dt ; 
void Update()
{
        UINT currTime = timeGetTime();
        //the first update?
        if(prevFrameTime == 0) {
                prevFrameTime = currTime;
                return;
        }
        
 
        dt = (currTime - prevFrameTime)/1000.0;
        // helic
        game.h.Update();
        game.h.animTimeSec += 2000 * dt;
 
        game.h2.Update();
        game.h2.animTimeSec += 2000 * dt;
 
        game.h3.Update();
        game.h3.animTimeSec += 2000 * dt;
 
        //game.bb.Update();
        game.bb.animTimeSec += 2000 * dt;
        
        game.buggy1.Update4();
        game.buggy2.Update3();
        game.buggy1.animTimeSec += 2000 * dt;
        game.buggy2.animTimeSec += 2000 * dt;

		game.p1.animTimeSec += 2000 * dt;
		game.p2.animTimeSec += 2000 * dt;
		game.p3.animTimeSec += 2000 * dt;
		game.p4.animTimeSec += 2000 * dt;
 
 
 
 
        if (mode == 1){   // For the moving Enemies " ONLY Second level " 
                if (!done1)
                        game.Enemy.Update2();
                if (!done2)
                        game.Enemy2.Update();
                if (!done3)
                        game.Enemy3.Update4();
                if (!done4)
                        game.Enemy4.Update();
                if (!done5)
                        game.Enemy5.Update3();
                if (!done6)
                        game.Enemy6.Update3();
                if (!done7)
                        game.Enemy7.Update2();
                if (!done8)
                        game.Enemy8.Update();
                if (!done9)
                        game.Enemy9.Update4();
                if (!done10)
                        game.Enemy10.Update4();
                if (!done11)
                        game.Enemy11.Update4();
                if (!done12)
                        game.Enemy12.Update2();
                if (!done13)
                        game.Enemy13.Update();
                if (!done14)
                        game.Enemy14.Update();
                if (!done15)
                        game.Enemy15.Update3();
                if (!done16)
                        game.Enemy16.Update2();
 
 
        }
 
 
 
        //Write all update code here.   
        prevFrameTime = currTime;
        CheckCollisions();
        game.HandleCollisions();
        game.Update(dt);
 
        spotAngle += 2;
        game.hero.animTimeSec += 120 * dt;
        
        //game.Enemy.animTimeSec += 120 * dt;
 
        //Display health, score, fps
        char titleStr[512];
        sprintf(titleStr, "Health: %d, Score: %d, Level : %d, fps: %f", game.heroHealth, game.heroScore, getLevel(mode), 1/dt);
        glutSetWindowTitle(titleStr);
}
 
void OnDisplay() {
        //set the background color to white
        glClearColor(0.94901, 0.9215, 0.81568, 1);
		
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
        
        SetTransformations();
        //drawing code geos here
 
 
    //    glPushMatrix();// this for the texture of the ground 
    //    {
    //    glScalef(10, 10, 10);
    //    // Inside OnPaint
    //            glRotatef(fRotAroundY, 0, 1, 0);
    //            // setup texture mapping
    //            glEnable( GL_TEXTURE_2D );
    //            //glPushMatrix();
    //            
    //            //glScalef(5,5,5);
    //            
    //            // glPopMatrix();
    //            //glBindTexture( GL_TEXTURE_2D, texture );
    //    DrawCube(); 
    //            glDisable(GL_TEXTURE_2D);
    //}
   // glPopMatrix();
        //glPushMatrix();
        //glEnable( GL_TEXTURE_2D );
        //glScalef(700,700,700);
        //glTranslatef(0, -.4f, -.6f);
    //    skybox();
		Draw3DSolarSystem();
    //    glDisable(GL_TEXTURE_2D);
     //   glPopMatrix();
        //SetLights();
        //SetMaterial();
        //if (SniperMode)
        //       // DrawSniper();
        RenderEnemiesCones();  // draw the enemies 
        game.Render();  
		RenderPlants();// draw the bullets 
        glFlush();
        glutSwapBuffers();
        Update();
        glutPostRedisplay();
}
 
 
int main(int argc, char* argv[]) {
//      engine = createIrrKlangDevice();
        //engine->play2D("C:/Users/user/Documents/Visual Studio 2012/Projects/HelloWorld-Sounds/media/MF-W-90.XM", true);
        largs = argv;
        largc = argc;
        int ret;
        ret = MessageBox(NULL, "Hello!!!\n Are you Ready to start the game :D ??", "Air Fight", MB_YESNO);
        if (ret == IDNO)
                return 0;
        timeBeginPeriod(1);
        InitGraphics(argc, argv);
        timeEndPeriod(1);
        return 0;
}
 
void DrawCube()
{
	//front face  z=0.5;
	glPushMatrix();
	
	glTranslatef(0,0,0.5f);
	glRotatef(-180,1,0,0);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
	glBindTexture(GL_TEXTURE_2D,texture1[0]);
	 

	
	DrawSquare(1,1);
	glPopMatrix();


	//back face
	glBindTexture(GL_TEXTURE_2D,texture1[0]);
	glPushMatrix();
	glTranslatef(0,0,-0.5f);
	glRotatef(180,0,1,0);
	//in fact, I rotate 180 deg about either the x-axis or 
	//the y-axis to bring the order of vertices ccw when 
	//the face seen from outside the cube
	DrawSquare(1,1);
	glPopMatrix();

	//right face: x=+0.5
	glBindTexture(GL_TEXTURE_2D,texture1[0]);
	glPushMatrix();
	glTranslatef(0.5f,0,0);
	glRotatef(90,0,1,0);
	DrawSquare(1,1);
	glPopMatrix();


	//left face: X=-0.5
	glPushMatrix();
	glTranslatef(-0.5f,0,0);
	glRotatef(90,0,1,0);
	DrawSquare(1,1);
	glPopMatrix();


	////btm face y=0.5
	//glBindTexture(GL_TEXTURE_2D,texture1[5]);
	//glPushMatrix();
	//glTranslatef(0,-1,0);
	//glRotatef(-90,1,0,0);
	//DrawSquare(1,1);
	//glPopMatrix();



	//up face y=-0,5
	glBindTexture(GL_TEXTURE_2D,texture1[3]);
	glPushMatrix();
	glTranslatef(0,-0.5f,0);
	glRotatef(90,1,0,0);
	DrawSquare(1,1);
	glPopMatrix();
	

}

void DrawSquare(int x,int y) {
	//draw a simple quad
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glBegin(GL_QUADS);

	glTexCoord2f(0,0);
		glVertex3f(-0.5f, -0.5f, 0);

		
glTexCoord2f(x,0);
	
		glVertex3f(0.5f, -0.5f, 0);

		
glTexCoord2f(x,y);
	
		glVertex3f(0.5f, 0.5f, 0);

		
glTexCoord2f(0,y);
	
		glVertex3f(-0.5f, 0.5f, 0);
	glEnd();
}
 
 
void DrawSquare(){
	// draw a simple quad
	glBegin(GL_QUADS);
	glTexCoord2f(0,0);
		glVertex3f(-0.5f,-0.5f,0);
		glTexCoord2f(0,1);
		glVertex3f(0.5f,-0.5f,0);
		glTexCoord2f(1,0);
		glVertex3f(0.5f,0.5f,0);
		glTexCoord2f(1,1);
		glVertex3f(-0,0.5f,0);

		glEnd();
}
// BALSH 
void Draw3DSolarSystem(){
	glPushMatrix();
	
	glEnable(GL_TEXTURE);
		glTranslatef(0,-5,0);
		glScalef(10000,700,10000);
		glTranslatef(0,0.6,0);
		DrawCube();
	glPopMatrix();
}
void InitGraphics(int argc, char *argv[]) {     
 
        InitEnemies();
        glutInit(&argc, argv);
        glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
        glutInitWindowPosition(100, 100); //pass (-1, -1) for Window-Manager defaults
        glutInitWindowSize(800, 800);
        glutCreateWindow("OpenGL Lab");
        glutKeyboardFunc(OnKeyboard);
        glutSpecialFunc(OnSpecial);
        glutDisplayFunc(OnDisplay);
 
        glEnable(GL_DEPTH_TEST);
        texture = LoadTextureRAW( "texture.raw", TRUE );  // for the texture
         int x =2;
        texture = LoadTextureRAW( "texture.raw", TRUE );
        texture1[0] = LoadTexture( "skybox/back.bmp", 256*x , 256*x ); //load the texture
        texture1[1] = LoadTexture( "skybox/front.bmp", 256*x, 256 *x); //load the texture
        //texture1[1] = LoadTexture( "skybox/front.bmp", 256*x, 256*x ); //load the texture
        texture1[2] = LoadTexture( "skybox/left.bmp", 256*x, 256 *x); //load the texture
        texture1[3] = LoadTexture( "skybox/right.bmp", 256*x, 256 *x); //load the texture
        texture1[4] = LoadTexture( "skybox/down.bmp", 256*x, 256*x ); //load the texture
        texture1[5] = LoadTexture( "skybox/up.bmp", 256*x, 256*x ); //load the texture
        
        //Reset the hero position, hero size, number of enemies, minimum position for enemies and maximum position for enemies
        game.Reset(Vector3(0,-50,-50) , 10, 0, Vector3(-50, 0, -30), Vector3(50, 0, -150), SniperAngle );
        glutMainLoop();
}
// for the texture
//void DrawCube() // for the texture
//{
  /*  glPushMatrix();
    {
        glColor3f(0.94901, 0.9215, 0.81568);
           glScalef(110,50,110);
       glTranslatef(0, -.4f, -.6f);
       glRotatef(90, 1, 0, 0);
        DrawSquare();
    }
    glPopMatrix();*/
//}
//void DrawSquare()  // for the texture
//{
    /*glBegin(GL_QUADS);
        glTexCoord2d(0.0,0.0);
        glVertex2f(-2, -2);
 
        glTexCoord2d(1.0,0.0);
    glVertex2f(2, -2);
 
        glTexCoord2d(1.0,1.0);
    glVertex2f(2, 2);
 
        glTexCoord2d(0.0,1.0);
    glVertex2f(-2, 2);
    glEnd();*/
//}   
void InitEnemies(){
 
        game.h.P=Vector3(-50 , 10 , 80);  // the heli 
        game.h2.P=Vector3(50 , 10 , -80);  // the heli 
        game.h3.P=Vector3(-50 , 10 , -80);  // the heli 
 
 
        game.bb.P=Vector3(70 , -50 , 60);
 
        game.buggy1.P=Vector3(50 , -50 , 100);
        game.buggy2.P=Vector3(-100 , -50 , -30);
 
        if (mode == 0 ){
        game.Enemy.P=Vector3(-50,-50,80);
        game.Enemy2.P=Vector3(-90,-50,0);
        game.Enemy3.P=Vector3(110,-50,0);
        game.Enemy4.P=Vector3(-50,-50,-90);
        game.Enemy5.P=Vector3(90,-50,40);
 
        game.Enemy6.P=Vector3(80,-50,100);
        game.Enemy7.P=Vector3(-9,-50, 120);
        game.Enemy8.P=Vector3(-10,-50,-100);
        game.Enemy9.P=Vector3(30,-50,-90);
        game.Enemy10.P=Vector3(90,-50,-40);
        game.Enemy11.P=Vector3(80,-50,-44);
        game.Enemy12.P=Vector3(-90,-50,50);
 
        game.Enemy13.P=Vector3(-60,-50,-90);
        game.Enemy14.P=Vector3(-90,-50,-10);
        game.Enemy15.P=Vector3(90,-50,60);
        game.Enemy16.P=Vector3(-20,-50,120);
        
        }
                if (mode == 1 ){
        game.h.P=Vector3(-50 , 20 , 80);  // the heli 
        game.h2.P=Vector3(50 , 20 , -80);  // the heli 
        game.h3.P=Vector3(-50 , 20 , -80);  // the heli                 
        game.Enemy.angle+=-90;
        game.Enemy2.angle+=-90;
        game.Enemy3.angle+=-90;
        game.Enemy4.angle+=-90;
        game.Enemy5.angle+=-90;
        game.Enemy6.angle+=-90;
        game.Enemy7.angle+=-90;
        game.Enemy8.angle+=-90;
        game.Enemy9.angle+=-90;
        game.Enemy10.angle+=-90;
        game.Enemy11.angle+=-90;
        game.Enemy12.angle+=-90;
        game.Enemy13.angle+=-90;
        game.Enemy14.angle+=-90;
        game.Enemy15.angle+=-90;
        game.Enemy16.angle+=-90;
        }
        
}

void RenderEnemiesCones()
{
 
        game.Enemy.Render();
        game.Enemy2.Render();
        game.Enemy3.Render();
        game.Enemy4.Render();
        game.Enemy5.Render();
        game.Enemy6.Render();
        game.Enemy7.Render();
        game.Enemy8.Render();
        game.Enemy9.Render();
        game.Enemy10.Render();
        game.Enemy11.Render();
        game.Enemy12.Render();
        game.Enemy13.Render();
        game.Enemy14.Render();
        game.Enemy15.Render();
        game.Enemy16.Render();
        

		game.h.Render();
        game.h2.Render();
        game.h3.Render();
 
        game.bb.Render();
 
        game.buggy1.Render();
        game.buggy2.Render();
 
 
 
 
 
}

void InitPlants()
{
	game.p1.P = Vector3(20, -50, 30);
	game.p2.P = Vector3(70, -50, 10);
	game.p3.P = Vector3(40, -50, -20);
	game.p4.P = Vector3(80, -50, 45);
}
void RenderPlants()
{
	game.p1.Render();
	game.p2.Render();
	game.p3.Render();
	game.p4.Render();
}

void CheckCollisions()
{
        
        AABoundingBox enemBox;
        size_t nBulls ;
        enemBox = game.Enemy.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                //              game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy.angle=90;
                                game.heroScore += 100;   // yet3'ayar 
                                done1=1;
                                break;
                        }
                }
                
 
                                 enemBox = game.Enemy2.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                        //      game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy2.angle=90;
                                game.heroScore += 100;
                                done2=1;
                                break;
                        }
                }
                                 enemBox = game.Enemy3.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy3.angle=90;
                                game.heroScore += 100;
                                done3=1;
                                break;
                        }
                }
                                 enemBox = game.Enemy4.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy4.angle=90;
                                game.heroScore += 100;
                                done4=1;
                                break;
                        }
                }
                                 enemBox = game.Enemy5.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy5.angle=90;
                                game.heroScore += 100;
                                done5=1;
                                break;
                        }
                }
                                 enemBox = game.Enemy6.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy6.angle=90;
                                done6=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
                 enemBox = game.Enemy7.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                        //      game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy7.angle=90;
                                done7=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
                 enemBox = game.Enemy8.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy8.angle=90;
                                done8=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
         enemBox = game.Enemy9.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy9.angle=90;
                                done9=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
                 enemBox = game.Enemy10.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy10.angle=90;
                                done10=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
 
                 enemBox = game.Enemy11.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy11.angle=90;
                                done11=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
                 enemBox = game.Enemy12.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                                //game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy12.angle=90;
                                done12=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
                 enemBox = game.Enemy13.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                        //      game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy13.angle=90;
                                done13=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
                 enemBox = game.Enemy14.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                        //      game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy14.angle=90;
                                done14=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
                 enemBox = game.Enemy15.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                        //      game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy15.angle=90;
                                done15=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
 
                 enemBox = game.Enemy16.GetAABB();
                 nBulls = game.heroBullets.size();
                for(int bullInd = nBulls-1; bullInd>=0; bullInd--) {
                        if(game.heroBullets[bullInd].GetAABB().IntersectsWith(enemBox)) {
                //              game.heroBullets.erase(game.heroBullets.begin() + bullInd);
                                game.Enemy16.angle=90;
                                done16=1;
                                game.heroScore += 100;
                                break;
                        }
                }
 
                if (!done1)                     
                  game.Enemy.animTimeSec += 120 * dt;
                if (!done2)                     
                  game.Enemy2.animTimeSec += 120 * dt;
                if (!done3)                     
                  game.Enemy3.animTimeSec += 120 * dt;
                if (!done4)                     
                  game.Enemy4.animTimeSec += 120 * dt;
                if (!done5)                     
                  game.Enemy5.animTimeSec += 120 * dt;
                if (!done6)                     
                  game.Enemy6.animTimeSec += 120 * dt;
 
                if (!done7)                     
                  game.Enemy7.animTimeSec += 120 * dt;
                if (!done8)                     
                  game.Enemy8.animTimeSec += 120 * dt;
                if (!done9)                     
                  game.Enemy9.animTimeSec += 120 * dt;
                if (!done10)                    
                  game.Enemy10.animTimeSec += 120 * dt;
                if (!done11)                    
                  game.Enemy11.animTimeSec += 120 * dt;
                if (!done12)                    
                  game.Enemy12.animTimeSec += 120 * dt;
                if (!done13)                    
                  game.Enemy13.animTimeSec += 120 * dt;
                if (!done14)                    
                  game.Enemy14.animTimeSec += 120 * dt;
                if (!done15)                    
                  game.Enemy15.animTimeSec += 120 * dt;
                if (!done16)                    
                  game.Enemy16.animTimeSec += 120 * dt;
 
 
                  int CurrentState = done1 + done2 + done3 + done4 + done5 + done6 +done7 + done8 + done9 + done10 + done11 + done12 + done13 + done14 + done15 + done16; 
                  if (CurrentState == 16 & mode== 0 ){
                        mode++;
                        done1 = done2 = done3 = done4 = done5 = done6=done7 = done8 = done9 = done10 = done11 = done12 = done13 = done14 = done15 = done16=0; 
                        InitEnemies();
                }
 
                
}